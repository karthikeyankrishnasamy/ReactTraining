
import React, { Component } from 'react';


class CounterTest extends Component
{
constructor(props) {
  super(props);
  this.state = { counter: this.props.counter };
  this.onIncrementCounter = this.onIncrementCounter.bind(this);
}

onIncrementCounter(){
    this.setState({counter:this.state.counter+1});
}



render()
{
  return(
        <React.Fragment>
        <div className='r-counter'>Counter: {this.state.counter}</div>
        <button className='r-button' onClick={this.onIncrementCounter}>+</button>
        </React.Fragment>
    );}}

    CounterTest.defaultProps = {counter: 0,};

export default CounterTest