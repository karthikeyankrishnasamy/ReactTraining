import React, { Component } from 'react';

//Class Components
class Person extends Component{
        render(){
            return(
            <div>
                <h1>{this.props.firstName}, {this.props.lastName}</h1>
                <h1>{this.props.message}</h1>
            </div>
            );
        }
    }

    Person.defaultProps = {
        message: 'Welcome to React JS Training...',
      
      };
 

class App extends Component {
    render() {
        return ( <React.Fragment>
                    <Person firstName = "Karthikeyan" lastName ="Krishnasamy"/>
                    <Person firstName = "David" lastName ="John" message="Welcome to Office 365 Training..."  />
                 </React.Fragment> 
        );
    }
}

export default App;