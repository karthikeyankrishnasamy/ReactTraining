import React, { Component } from 'react';

class Toggle extends React.Component {
    constructor(props) {
      super(props);
      this.state = {isToggleOn: true};
   
    }
   //This is arrow method
    handleClick = () =>{
      this.setState(state => ({
        isToggleOn: !state.isToggleOn
      }));
    }
  
    render() {
        const style=this.state.isToggleOn? "r-button-on" : "r-button-off"
      return (
        <button className={style} onClick={this.handleClick}>
          {this.state.isToggleOn ? 'ON' : 'OFF'}
        </button>
      );
    }
  }

class App extends Component {
    render() {
        return ( <React.Fragment>
                    <Toggle />
                 </React.Fragment> 
        );
    }
}

export default App;