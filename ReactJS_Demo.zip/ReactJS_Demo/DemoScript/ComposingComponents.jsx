import React, { Component } from 'react';

//Class Components
class Person extends Component{
    constructor(props){
        super(props)
        this.state={date:new Date()}
    }
    
        render(){
            return(
            <div>
                <h1>{this.props.firstName}, {this.props.lastName}</h1>
                <h2> Today Date is {this.state.date.toLocaleDateString()}</h2>
                {this.props.children}
                <div style={{height:'50px'}}></div>
                {this.props.notes}
            </div>

            );
        }
    }

    Person.defaultProps = {
        notes: 'Welcome to React JS Training...',
      
      };
  function NewsLetter(props){
        return <div style={{backgroundColor : props.bgColor}}>{props.news}</div>
  }  

class App extends Component {
    render() {
        return ( <React.Fragment>
                    <Person firstName = "Karthikeyan" lastName ="Krishnasamy">
                            <h1>Welcome to React JS Training</h1>
                    </Person>
                    <Person firstName = "David" lastName ="Kumar"  />
                    <Person firstName = "Aravind" lastName ="S"  />
                    <Person firstName = "John" lastName ="Kennedy">
                        <NewsLetter bgColor ="Blue" news="Wish you a Happy Birthday... "/>
                        <NewsLetter bgColor ="Red" news="Some News... "/>
                    </Person>
                 </React.Fragment> 
        );
    }
}

export default App;