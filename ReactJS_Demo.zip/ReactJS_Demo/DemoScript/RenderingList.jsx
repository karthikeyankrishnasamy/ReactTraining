import React, { Component } from 'react';

function Welcome(props){
    return <h1>{props.message}</h1>
}

class TagList extends Component {
    constructor(props) {
     super(props);
     this.state = {tags :["Tag1", "Tag2", "Tag3","Tag4"]};
   }
   
   render() {
       const welcomeList=[<Welcome key="1" message="Welcome message 1"/>,
       <Welcome key="2" message="Welcome message 2"/>,
       <Welcome key="3" message="Welcome message 3"/>
    ]
     return(
       <div>
         <ul>{this.state.tags.map(tag => <li key={tag}>{tag}</li>)}</ul>
         {welcomeList}
       </div>
     );
   }
 }

class App extends Component {
    render() {
        return ( <React.Fragment>
                    <TagList />
                 </React.Fragment> 
        );
    }
}

export default App;