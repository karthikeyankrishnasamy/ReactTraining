import React, { Component } from 'react';

class Counters extends Component
{
constructor(props) {
  super(props);
  this.state = { counter: this.props.counter };
  this.onIncrementCounter = this.onIncrementCounter.bind(this);
}

onIncrementCounter(){
    this.setState({counter:this.state.counter+1});
}
render()
{
  return(
        <React.Fragment>
        <div className='r-counter'>Counter: {this.state.counter}</div>
        <button className='r-button' onClick={this.onIncrementCounter}>+</button>
        </React.Fragment>
    );}}

Counters.defaultProps = {counter: 0,};
class App extends Component {
    render() {
        return ( <React.Fragment>
                    <Counters/>
                 </React.Fragment> 
        );
    }
}

export default App;