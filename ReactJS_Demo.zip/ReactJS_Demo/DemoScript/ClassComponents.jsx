import React, { Component } from 'react';
//Class Components
class Person extends Component{
    constructor(props){
        super(props)
        this.state={date:new Date()}
    }
        render(){
            return(
            <div>
                <h1>{this.props.firstName}, {this.props.lastName}</h1>
                <h2> Today Date is {this.state.date.toLocaleDateString()}</h2>
            </div> );
        }
    }
class App extends Component {
    render() {
        return ( <React.Fragment>
                    <Person firstName = "Karthikeyan" lastName ="Krishnasamy"  />
                 </React.Fragment> );
    }
}
export default App;