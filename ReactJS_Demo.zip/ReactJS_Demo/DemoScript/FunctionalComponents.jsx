import React, { Component } from 'react';

//Function Components
function Welcome(props) {
    const name=props.firstName+' '+props.lastName;
    return <h1> Welcome { name }  </h1>
}
class App extends Component {
    render() {
        return ( <React.Fragment>
                    <Welcome firstName = "Karthikeyan" lastName ="Krishnasamy"  />
                 </React.Fragment> 
        );
    }
}

export default App;